const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const methodOverride = require('method-override');
const ejsmate = require('ejs-mate');
const session = require('express-session');
const flash = require('connect-flash');
const joi = require('joi');
const Expresserror = require('./utilis/Expresserror')
const catchAsync = require('./utilis/catchAsync');
const Trail = require('./models/trail');
const User = require('./models/user');
const Query = require('./models/query');

mongoose.connect('mongodb://localhost:27017/trailup');

const db = mongoose.connection;
db.on('error', console.error.bind(console, "connection error:"));
db.once("open", () => {
    console.log("✅ Database connected to trailup");
});

const app = express();

app.engine('ejs', ejsmate)
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.urlencoded({ extended: true }));
app.use(methodOverride('_method'));
app.use(session({
    secret: 'trailsecret',
    resave: false,
    saveUninitialized: true
}));
app.use(flash());

app.use((req, res, next) => {
    res.locals.currentUser = req.session.userId || null;
    next();
});

app.use((req, res, next) => {
    res.locals.success = req.flash('success');
    res.locals.error = req.flash('error');
    res.locals.currentUser = req.session.userId || null;
    next();
});

app.get('/', (req, res) => {
    res.render('home');
});

// INDEX - all trails
app.get('/trails', async (req, res) => {
    const trails = await Trail.find({});
    res.render('trails/index', { trails });
});

//login-user login
app.get('/login', (req, res) => {
    res.render('user/login', { error: null });
});


//user-page
app.post('/login', async (req, res) => {
    try {
        const { username, email } = req.body;
        const user = await User.findOne({ username, email });
        if (!user) {
            // return res.render('user/login', { error: 'Invalid username or email' });
            req.flash('error', 'Invalid username or email');
            return res.redirect('/login');
        }
        req.session.userId = user._id;
        req.flash('success', 'Welcome back!');
        res.redirect(`/user/${user._id}`);
        // successful login logic
    }
    catch (err) {
        req.flash('error', 'Something went wrong. Please try again.');
        res.redirect('/login');
    }
});

app.post('/logout', (req, res) => {
    req.session.userId = null;
    req.flash('success', 'Logged out successfully.');
    res.redirect('/');
});

app.use((req, res, next) => {
    res.locals.userId = req.session.userId;
    next();
});

//creating new user
app.get('/new', async (req, res) => {
    res.render('user/new');
})

app.post('/user', async (req, res) => {
    const userData = req.body.user;

    if (typeof userData.talents === 'string') {
        userData.talents = userData.talents.split(',').map(s => s.trim());
    }

    const newUser = new User(userData);
    await newUser.save();
    req.session.userId = newUser._id;
    req.flash('success', 'Account created successfully!');
    res.redirect(`/user/${newUser._id}`);
});

//show-single user
app.get('/user/:id', async (req, res) => {
    const { id } = req.params;
    const user = await User.findById(id);
    if (!user) {
        return res.status(404).send("User not found");
    }
    const trails = await Trail.find({ author: id });
    res.render('user/show', { user, trails });
})

function requireLogin(req, res, next) {
    if (!req.session.userId) {
        return res.redirect('/login');
    }
    next();
}

//function which helps to authorisation check
async function isAuthor(req, res, next) {
    const { id, trailId } = req.params;
    const trail = await Trail.findById(id || trailId); // supports both /trails/:id and /trails/:trailId
    if (!trail) return res.status(404).send("Trail not found");

    if (!trail.author.equals(req.session.userId)) {
        return res.status(403).send("You don't have permission to do that");
    }

    next();
}

// NEW - form to create a trail
app.get('/trails/new', (req, res) => {
    const sessionUserId = req.session.userId;
    const queryUserId = req.query.user;

    // If not logged in
    if (!sessionUserId) {
        return res.status(403).send("You must be logged in to create a trail.");
    }

    // If user tries to fake another user's ID
    if (queryUserId !== sessionUserId) {
        return res.status(403).send("You can only create trails for your own profile.");
    }

    res.render('trails/new', { userId: sessionUserId });
});

// CREATE - add new trail to DB
app.post('/trails', catchAsync(async (req, res, next) => {
    const trailData = req.body.trail;
    const sessionUserId = req.session.userId;

    // No one should post if not logged in
    if (!sessionUserId) {
        req.flash('error', 'You must be logged in to submit a trail.');
        return res.redirect('/login');
    }

    // Don't trust the hidden input blindly — override it
    trailData.author = sessionUserId;

    const trail = new Trail(trailData);
    await trail.save();

    const user = await User.findById(sessionUserId);
    user.trails.push(trail._id);
    await user.save();

    req.flash('success', 'New trail created!');
    res.redirect(`/trails/${trail._id}`);
}));

// SHOW - single trail
app.get('/trails/:id', async (req, res) => {
    const { id } = req.params;
    const trail = await Trail.findById(id).populate('author');
    const queries = await Query.find({ trail: id }).populate('author');
    if (!trail) {
        return res.status(404).send("Trail not found");
    }
    res.render('trails/show', { trail, queries });
});

// EDIT - form to edit trail
app.get('/trails/:id/edit', requireLogin, isAuthor, async (req, res) => {
    const { id } = req.params;
    const trail = await Trail.findById(id);
    if (!trail) {
        return res.status(404).send("Trail not found");
    }
    res.render('trails/edit', { trail });
});

// UPDATE - update trail in DB
app.put('/trails/:id', requireLogin, isAuthor, async (req, res, next) => {
    const { id } = req.params;
    try {
        const trail = await Trail.findByIdAndUpdate(id, req.body.trail, { new: true });
        if (!trail) {
            req.flash('error', 'Trail not found.');
            return res.redirect('/trails')
        }
        res.redirect(`/trails/${trail._id}`);
    } catch (e) {
        console.error(e);
        req.flash('error', 'Error updating trail.');
        res.redirect('/trails');
        // res.status(500).send("Error updating trail");
        //next(e);
    }
});

// DELETE - remove trail
app.delete('/trails/:id', requireLogin, isAuthor, async (req, res) => {
    const { id } = req.params;
    await Trail.findByIdAndDelete(id);
    req.flash('success', 'Trail deleted successfully.');
    res.redirect('/trails');
});

app.post('/trails/:id/milestones', requireLogin, isAuthor, async (req, res) => {
    const { id } = req.params;
    const trail = await Trail.findById(id);
    if (!trail) {
        req.flash('error', 'Trail not found.');
        return res.redirect('/trails');
    }
    trail.milestones.push(req.body.milestone);
    await trail.save();
    req.flash('success', 'Milestone added successfully.');
    res.redirect(`/trails/${id}`);

});

app.get('/trails/:trailId/milestones/:milestoneId/edit', requireLogin, isAuthor, async (req, res) => {
    const { trailId, milestoneId } = req.params;
    const trail = await Trail.findById(trailId);
    const milestone = trail.milestones.id(milestoneId);
    if (!milestone) return res.status(404).send("Milestone not found");
    res.render('milestones/edit', { trail, milestone });
});

app.put('/trails/:trailId/milestones/:milestoneId', requireLogin, isAuthor, async (req, res) => {
    const { trailId, milestoneId } = req.params;
    const trail = await Trail.findById(trailId);
    const milestone = trail.milestones.id(milestoneId);
    if (!milestone) {
        // return res.status(404).send("Milestone not found");
        req.flash('error', 'milestone not found');
        res.redirect('/trails/${trailId}');
    }
    milestone.set(req.body.milestone);
    await trail.save();
    req.flash('success', 'milestone updated successfully');
    res.redirect(`/trails/${trailId}`);
});

app.delete('/trails/:trailId/milestones/:milestoneId', requireLogin, isAuthor, async (req, res) => {
    const { trailId, milestoneId } = req.params;
    await Trail.findByIdAndUpdate(trailId, {
        $pull: { milestones: { _id: milestoneId } }
    });
    req.flash('success', 'Milestone deleted.');
    res.redirect(`/trails/${trailId}`);
});

app.post('/trails/:trailId/queries', async (req, res) => {
    const { trailId } = req.params;
    const trail = await Trail.findById(trailId);

    const query = new Query({
        content: req.body.query.content,
        author: req.session.userId,
        trail: trailId
    });

    await query.save();
    res.redirect(`/trails/${trailId}`);
});

app.get('/trails/:trailId/queries/:queryId/edit', requireLogin, isAuthor, async (req, res) => {
    const { trailId, queryId } = req.params;
    const query = await Query.findById(queryId);

    if (!query) {
        req.flash('error', 'Query not found.');
        return res.redirect(`/trails/${trailId}`);
    }

    if (!query.author.equals(req.session.userId)) {
        req.flash('error', 'You are not authorized to edit this query.');
        return res.redirect(`/trails/${trailId}`);
    }

    res.render('queries/edit', { query, trailId });
});

app.put('/trails/:trailId/queries/:queryId', requireLogin, isAuthor, async (req, res) => {
    const { trailId, queryId } = req.params;
    const query = await Query.findById(queryId);

    if (!query) {
        req.flash('error', 'Query not found.');
        return res.redirect(`/trails/${trailId}`);
    }

    if (!query.author.equals(req.session.userId)) {
        req.flash('error', 'You are not authorized to update this query.');
        return res.redirect(`/trails/${trailId}`);
    }

    query.content = req.body.query.content;
    await query.save();

    req.flash('success', 'Query updated successfully.');
    res.redirect(`/trails/${trailId}`);
});


app.delete('/trails/:trailId/queries/:queryId', async (req, res) => {
    const { trailId, queryId } = req.params;
    const query = await Query.findById(queryId);

    if (req.session.userId === query.author && query) {
        await Query.findByIdAndDelete(queryId);
    }
    req.flash('success', 'query deleted successfully')
    res.redirect(`/trails/${trailId}`);
});


app.get('/user/:id/edit', async (req, res) => {
    const { id } = req.params;
    const user = await User.findById(id);
    if (!user) {
        return res.status(404).send("User not found");
    }
    res.render('user/edit', { user });
});

app.put('/user/:id/', async (req, res) => {
    const { id } = req.params;
    const userData = req.body.user;

    if (typeof userData.talents === 'string') {
        userData.talents = userData.talents.split(',').map(skill => skill.trim());
    }

    const updatedUser = await User.findByIdAndUpdate(id, userData, { new: true });
    req.flash('success', 'Profile updated successfully.');
    res.redirect(`/user/${id}`);
});

// Delete user and all their trails
app.delete('/user/:id', async (req, res) => {
    const { id } = req.params;

    // Delete all trails by this user
    await Trail.deleteMany({ author: id });
    // Delete the user
    await User.findByIdAndDelete(id);

    req.flash('success', 'Your account and trails have been deleted.');
    res.redirect('/'); // or /login
});

app.all(/(.*)/, (req, res, next) => {
    next(new Expresserror('page not found', 404))
})

app.use((err, req, res, next) => {
    const { status = 500 } = err;
    if (!err.message) err.message = 'something went wrong'
    res.status(status).render('error', { err })
    // res.send('hey something went wrong!')
})

app.listen(3000, () => {
    console.log("🚀 Serving on port 3000");
});
