const Trail = require('./models/trail');

// Middleware to check if user is logged in
function requireLogin(req, res, next) {
    if (!req.session.userId) {
        req.flash('error', 'You must be logged in first!');
        return res.redirect('/login');
    }
    next();
}

// Middleware to check if the current user is the author of the trail
async function isAuthor(req, res, next) {
    const { id, trailId } = req.params;
    const trail = await Trail.findById(id || trailId);
    if (!trail) {
        req.flash('error', 'Trail not found');
        return res.redirect('/trails');
    }
    if (!trail.author.equals(req.session.userId)) {
        req.flash('error', "You don't have permission to do that.");
        return res.redirect(`/trails/${trail._id}`);
    }
    next();
}

module.exports = {
    requireLogin,
    isAuthor
};
