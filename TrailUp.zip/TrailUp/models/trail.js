const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const Query = require('./query');

const TrailSchema = new Schema({
    title: String, // e.g., "My Journey to UI/UX Design"
    field: String, // e.g., "Computer Science", "Design"
    description: String, // Overview of the journey
    location: String, // Optional: e.g., college/university
    milestones: [      // Key part: timeline of the journey
        {
            type: {
                type: String,
                enum: ['Course', 'Project', 'Internship', 'Job', 'Achievement','Applied'],
                required: true
            },
            title: String,
            description: String,
            date: Date
        }
    ],
    author: {
        type: Schema.Types.ObjectId,
        ref: 'User'
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

TrailSchema.post('findOneAndDelete', async function (doc) {
    if (doc) {
        await Query.deleteMany({ trail: doc._id });
    }
});

module.exports = mongoose.model('Trail', TrailSchema);
