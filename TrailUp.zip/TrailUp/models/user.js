// models/user.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const UserSchema = new Schema({
    username: String,
    email: String,
    college: String,    
    degree: String,
    talents: [String],
    trails: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Trail' }]
});

module.exports = mongoose.model('User', UserSchema);
