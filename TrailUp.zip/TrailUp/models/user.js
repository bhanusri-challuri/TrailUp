// models/user.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const Trail = require('./trail'); 

const UserSchema = new Schema({
    username: String,
    email: String,
    college: String,    
    degree: String,
    talents: [String],
    trails: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Trail' }]
});

UserSchema.post('findOneAndDelete', async function (doc) {
    if (doc) {
        await Trail.deleteMany({ author: doc._id });
    }
});

module.exports = mongoose.model('User', UserSchema);
