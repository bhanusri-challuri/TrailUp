const express = require('express');
const router = express.Router();
const Query = require('../models/query');
const { requireLogin } = require('../middleware');
const catchAsync = require('../utilis/catchAsync');

// CREATE query
router.post('/:trailId/queries', requireLogin, catchAsync(async (req, res) => {
  const { trailId } = req.params;
  const query = new Query({
    content: req.body.query.content,
    author: req.session.userId,
    trail: trailId
  });
  await query.save();
  req.flash('success', 'Comment added');
  res.redirect(`/trails/${trailId}`);
}));

// DELETE query
router.delete('/:trailId/queries/:queryId', requireLogin, catchAsync(async (req, res) => {
  const { trailId, queryId } = req.params;
  const query = await Query.findById(queryId);
  if (!query.author.equals(req.session.userId)) {
    req.flash('error', "You don't have permission to delete this comment.");
    return res.redirect(`/trails/${trailId}`);
  }
  await Query.findByIdAndDelete(queryId);
  req.flash('success', 'Comment deleted');
  res.redirect(`/trails/${trailId}`);
}));

module.exports = router;
