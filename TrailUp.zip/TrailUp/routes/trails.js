// routes/trails.js
const express = require('express');
const router = express.Router();
const Trail = require('../models/trail');
const User = require('../models/user');
const catchAsync = require('../utilis/catchAsync');
const { requireLogin, isAuthor } = require('../middleware');
const queryRoutes = require('./queries');
router.use('/:trailId/queries', queryRoutes);


// INDEX
router.get('/', catchAsync(async (req, res) => {
  const trails = await Trail.find({});
  res.render('trails/index', { trails });
}));

// NEW
router.get('/new', requireLogin, (req, res) => {
  const sessionUserId = req.session.userId;
  const queryUserId = req.query.user;
  if (!sessionUserId || sessionUserId !== queryUserId) {
    req.flash('error', 'Unauthorized');
    return res.redirect('/login');
  }
  res.render('trails/new', { userId: sessionUserId });
});

// CREATE
router.post('/', requireLogin, catchAsync(async (req, res) => {
  const trailData = req.body.trail;
  trailData.author = req.session.userId;
  const trail = new Trail(trailData);
  await trail.save();
  const user = await User.findById(req.session.userId);
  user.trails.push(trail._id);
  await user.save();
  req.flash('success', 'Trail created successfully');
  res.redirect(`/trails/${trail._id}`);
}));

// SHOW
router.get('/:id', catchAsync(async (req, res) => {
  const { id } = req.params;
  const trail = await Trail.findById(id).populate('author');
  const queries = await require('../models/query').find({ trail: id }).populate('author');
  if (!trail) {
    req.flash('error', 'Trail not found');
    return res.redirect('/trails');
  }
  res.render('trails/show', { trail, queries });
}));

// EDIT
router.get('/:id/edit', requireLogin, isAuthor, catchAsync(async (req, res) => {
  const { id } = req.params;
  const trail = await Trail.findById(id);
  res.render('trails/edit', { trail });
}));

// UPDATE
router.put('/:id', requireLogin, isAuthor, catchAsync(async (req, res) => {
  const { id } = req.params;
  const trail = await Trail.findByIdAndUpdate(id, req.body.trail, { new: true });
  req.flash('success', 'Trail updated');
  res.redirect(`/trails/${trail._id}`);
}));

// DELETE
router.delete('/:id', requireLogin, isAuthor, catchAsync(async (req, res) => {
  await Trail.findByIdAndDelete(req.params.id);
  req.flash('success', 'Trail deleted');
  res.redirect('/trails');
}));

// MILESTONES
router.post('/:id/milestones', requireLogin, isAuthor, catchAsync(async (req, res) => {
  const trail = await Trail.findById(req.params.id);
  trail.milestones.push(req.body.milestone);
  await trail.save();
  req.flash('success', 'Milestone added!');
  res.redirect(`/trails/${trail._id}`);
}));

router.get('/:trailId/milestones/:milestoneId/edit', requireLogin, isAuthor, catchAsync(async (req, res) => {
  const { trailId, milestoneId } = req.params;
  const trail = await Trail.findById(trailId);
  const milestone = trail.milestones.id(milestoneId);
  if (!milestone) {
    req.flash('error', 'Milestone not found');
    return res.redirect(`/trails/${trailId}`);
    }
  res.render('milestones/edit', { trail, milestone });
}));

router.put('/:trailId/milestones/:milestoneId', requireLogin, isAuthor, catchAsync(async (req, res) => {
  const { trailId, milestoneId } = req.params;
  const trail = await Trail.findById(trailId);
  const milestone = trail.milestones.id(milestoneId);
  milestone.set(req.body.milestone);
  await trail.save();
  req.flash('success', 'Milestone updated!');
  res.redirect(`/trails/${trailId}`);
}));

router.delete('/:trailId/milestones/:milestoneId', requireLogin, isAuthor, catchAsync(async (req, res) => {
    const { trailId, milestoneId } = req.params;
    await Trail.findByIdAndUpdate(trailId, {
        $pull: { milestones: { _id: milestoneId } }
    });
    req.flash('success', 'Milestone deleted!');
    res.redirect(`/trails/${trailId}`);
}));

module.exports = router;
