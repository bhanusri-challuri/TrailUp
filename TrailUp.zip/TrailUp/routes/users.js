// File: routes/users.js
const express = require('express');
const router = express.Router();
const User = require('../models/user');
const Trail = require('../models/trail');
const catchAsync = require('../utilis/catchAsync');

router.get('/new', (req, res) => {
  res.render('user/new');
});

router.post('/', catchAsync(async (req, res) => {
  const userData = req.body.user;
  if (typeof userData.talents === 'string') {
    userData.talents = userData.talents.split(',').map(s => s.trim());
  }
  const newUser = new User(userData);
  await newUser.save();
  req.session.userId = newUser._id;
  res.redirect(`/user/${newUser._id}`);
}));

router.get('/:id', catchAsync(async (req, res) => {
  const { id } = req.params;
  const user = await User.findById(id);
  if (!user) {
    req.flash('error', 'User not found');
    return res.redirect('/');
  }
  const trails = await Trail.find({ author: id });
  res.render('user/show', { user, trails });
}));

router.get('/:id/edit', catchAsync(async (req, res) => {
  const { id } = req.params;
  const user = await User.findById(id);
  if (!user) {
    req.flash('error', 'User not found');
    return res.redirect('/');
  }
  res.render('user/edit', { user });
}));

router.put('/:id', catchAsync(async (req, res) => {
  const { id } = req.params;
  const userData = req.body.user;
  if (typeof userData.talents === 'string') {
    userData.talents = userData.talents.split(',').map(skill => skill.trim());
  }
  await User.findByIdAndUpdate(id, userData, { new: true });
  req.flash('success', 'User updated');
  res.redirect(`/user/${id}`);
}));

router.delete('/:id', catchAsync(async (req, res) => {
  const { id } = req.params;
  await Trail.deleteMany({ author: id });
  await User.findByIdAndDelete(id);
  req.flash('success', 'User and related trails deleted');
  res.redirect('/');
}));

module.exports = router;
