const mongoose = require('mongoose');
const usersData = require('./users');
const trailsData = require('./trails');
const User = require('../models/user');
const Trail = require('../models/trail');

mongoose.connect('mongodb://localhost:27017/trailup', {
   // useNewUrlParser: true,
 //   useUnifiedTopology: true
});

const db = mongoose.connection;
db.on('error', console.error.bind(console, "connection error:"));
db.once("open", () => {
    console.log("✅ Database connected");
});

const seedDB = async () => {
    await User.deleteMany({});
    await Trail.deleteMany({});
    console.log("🧹 Cleared old users and trails");

    const userMap = {};

    // Insert Users
    for (let userData of usersData) {
        const user = new User(userData);
        await user.save();
        userMap[user.email] = user._id; // email => ObjectId
    }
    console.log("✅ Users seeded");

    // Insert Trails
    for (let trailData of trailsData) {
        const authorId = userMap[trailData.authorEmail];
        if (!authorId) continue;

        const { authorEmail, ...cleanTrail } = trailData; // remove email from trail
        const trail = new Trail({
            ...cleanTrail,
            author: authorId
        });

        await trail.save();
    }
    console.log("✅ Trails seeded");
};

seedDB().then(() => {
    mongoose.connection.close();
    console.log("🚪 Database connection closed");
});
