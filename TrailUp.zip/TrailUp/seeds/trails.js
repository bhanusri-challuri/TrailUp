module.exports = [
    {
      title: "My Journey into Pharmacist, hospital",
      field: "Mechanical Engineering",
      location: "Robinson and Sons",
      description: "Entire fall energy game phone people answer listen floor.",
      milestones: [
        {
          type: "Internship",
          title: "Internship in Orchestrate Collaborative Applications",
          description: "Management sea attack successful partner.",
          date: "2024-02-10"
        },
        {
          type: "Project",
          title: "Project in Re-Contextualize 24/7 Roi",
          description: "Call more matter strong read picture current.",
          date: "2023-12-12"
        },
        {
          type: "Internship",
          title: "Internship in Drive Holistic Supply-Chains",
          description: "Range whom head his check.",
          date: "2024-01-13"
        }
      ],
      authorEmail: "daniellegray@white.biz"
    },
    {
      title: "My Journey into Financial manager",
      field: "Psychology",
      location: "Sawyer, Hernandez and Marshall",
      description: "Under former painting cultural total parent event recently.",
      milestones: [
        {
          type: "Job",
          title: "Job in Disintermediate Compelling Roi",
          description: "Article think mission style front.",
          date: "2023-04-08"
        },
        {
          type: "Project",
          title: "Project in Engineer Value-Added Markets",
          description: "Participant pull show. His agency southern.",
          date: "2025-02-26"
        },
        {
          type: "Course",
          title: "Course in Envisioneer Rich Convergence",
          description: "According American win close project mind large general.",
          date: "2023-05-19"
        }
      ],
      authorEmail: "carlreyes@gmail.com"
    },
    {
      title: "My Journey into Full Stack Engineering",
      field: "Computer Science",
      location: "Hernandez-Brown",
      description: "Started from frontend tutorials and ended up building scalable web apps.",
      milestones: [
        {
          type: "Course",
          title: "Course in JavaScript Essentials",
          description: "Mastered fundamentals of JS and DOM manipulation.",
          date: "2022-03-15"
        },
        {
          type: "Project",
          title: "Project in Building a MERN App",
          description: "Created a blogging platform using Mongo, Express, React, and Node.",
          date: "2023-01-10"
        }
      ],
      authorEmail: "brandon.harris@example.com"
    },
    {
      title: "My Journey into Product Marketing",
      field: "Marketing",
      location: "Wright-Hughes",
      description: "Pivoted from finance to product marketing through internships and strategy work.",
      milestones: [
        {
          type: "Internship",
          title: "Internship at MarketPro",
          description: "Helped with launch strategy for a new SaaS product.",
          date: "2022-07-01"
        },
        {
          type: "Achievement",
          title: "Top 5 in Global Marketing Challenge",
          description: "Ranked in the top 5 globally for go-to-market plan.",
          date: "2023-04-15"
        }
      ],
      authorEmail: "jennifer.thomas@example.com"
    },
    {
      title: "My Journey into Digital Advertising",
      field: "Marketing",
      location: "Carter Ltd.",
      description: "Worked on Google Ads campaigns and eCommerce sales strategy.",
      milestones: [
        {
          type: "Course",
          title: "Course in Digital Marketing",
          description: "Learned SEO, SEM, and performance metrics.",
          date: "2021-09-01"
        }
      ],
      authorEmail: "david.lee92@example.com"
    },
    {
      title: "My Journey into Research & Data Science",
      field: "Biotechnology",
      location: "Thompson PLC",
      description: "Applied bioinformatics and data science in pharmaceutical research.",
      milestones: [
        {
          type: "Project",
          title: "Project on Protein Modeling",
          description: "Simulated protein folding in Python.",
          date: "2022-05-20"
        },
        {
          type: "Job",
          title: "Research Assistant at BioLabs",
          description: "Analyzed large-scale data from lab experiments.",
          date: "2023-10-01"
        }
      ],
      authorEmail: "samantha.johnson@example.com"
    },
    {
      title: "My Journey into UI/UX Design",
      field: "Design",
      location: "Peters LLC",
      description: "Designed user interfaces for mobile apps and got into UX research.",
      milestones: [
        {
          type: "Project",
          title: "Redesigning an E-Commerce App",
          description: "Improved UI and checkout flow for a fashion store.",
          date: "2022-02-18"
        }
      ],
      authorEmail: "alex.martinez@example.com"
    },
    {
      title: "My Journey into Tech Management",
      field: "Computer Science",
      location: "Russell and Sons",
      description: "Moved from developer role into team leadership and project delivery.",
      milestones: [
        {
          type: "Job",
          title: "Project Manager at CodeBridge",
          description: "Led team of 6 engineers for a SaaS product.",
          date: "2024-01-12"
        }
      ],
      authorEmail: "karen.clark@example.com"
    },
    {
      title: "My Journey into Brand Strategy",
      field: "Marketing",
      location: "Bailey Inc.",
      description: "Explored market positioning and customer perception strategies.",
      milestones: [
        {
          type: "Internship",
          title: "Brand Intern at BrandX",
          description: "Assisted in designing visual identity for a product line.",
          date: "2023-06-05"
        }
      ],
      authorEmail: "chris.roberts@example.com"
    },
    {
      title: "My Journey into Organizational Psychology",
      field: "Psychology",
      location: "Howard-Ramirez",
      description: "Studied team dynamics and mental health at work.",
      milestones: [
        {
          type: "Course",
          title: "Intro to Organizational Behavior",
          description: "Learned workplace psychology theories.",
          date: "2021-11-20"
        }
      ],
      authorEmail: "laura.baker@example.com"
    },
    {
      title: "My Journey into Clinical Data Analysis",
      field: "Biotechnology",
      location: "Foster Group",
      description: "Analyzed drug trial results and medical datasets.",
      milestones: [
        {
          type: "Internship",
          title: "Internship at MediStat",
          description: "Worked on dashboards for real-time health data.",
          date: "2023-09-10"
        }
      ],
      authorEmail: "matthew.davis@example.com"
    },
    {
      title: "My Journey into Frontend Engineering",
      field: "Computer Science",
      location: "Butler LLC",
      description: "Focused on React, UI libraries, and accessibility.",
      milestones: [
        {
          type: "Project",
          title: "Personal Blog with React",
          description: "Built and deployed my tech blog.",
          date: "2022-06-18"
        }
      ],
      authorEmail: "andrea.wilson@example.com"
    }
  ];
  