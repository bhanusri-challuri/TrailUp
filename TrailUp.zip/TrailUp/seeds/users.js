module.exports = [
    {
      username: "wardemily",
      email: "daniellegray@white.biz",
      college: "Robinson and Sons",
      degree: "B.A. in Psychology",
      talents: ["Data Analysis", "Web Development", "Project Management"]
    },
    {
      username: "holly17",
      email: "carlreyes@gmail.com",
      college: "Sawyer, Hernandez and Marshall",
      degree: "BBA in Marketing",
      talents: ["Data Analysis", "Web Development", "Machine Learning"]
    },
    {
      username: "brandonharris",
      email: "brandon.harris@example.com",
      college: "Hernandez-Brown",
      degree: "B.Tech in Computer Science",
      talents: ["Web Development", "Machine Learning", "UI/UX Design"]
    },
    {
      username: "jenniferthomas",
      email: "jennifer.thomas@example.com",
      college: "Wright-Hughes",
      degree: "MBA in Finance",
      talents: ["Marketing Strategy", "Project Management", "Public Speaking"]
    },
    {
      username: "davidlee92",
      email: "david.lee92@example.com",
      college: "Carter Ltd.",
      degree: "BBA in Marketing",
      talents: ["Marketing Strategy", "Web Development"]
    },
    {
      username: "samanthajohnson",
      email: "samantha.johnson@example.com",
      college: "Thompson PLC",
      degree: "B.Sc in Biotechnology",
      talents: ["Machine Learning", "Data Analysis", "Public Speaking"]
    },
    {
      username: "alexmartinez",
      email: "alex.martinez@example.com",
      college: "Peters LLC",
      degree: "B.Des in Communication Design",
      talents: ["UI/UX Design", "Graphic Design", "Web Development"]
    },
    {
      username: "karenclark",
      email: "karen.clark@example.com",
      college: "Russell and Sons",
      degree: "B.Tech in Computer Science",
      talents: ["Web Development", "Project Management", "Machine Learning"]
    },
    {
      username: "chrisroberts",
      email: "chris.roberts@example.com",
      college: "Bailey Inc.",
      degree: "BBA in Marketing",
      talents: ["Marketing Strategy", "Public Speaking"]
    },
    {
      username: "laurabaker",
      email: "laura.baker@example.com",
      college: "Howard-Ramirez",
      degree: "B.A. in Psychology",
      talents: ["Data Analysis", "Project Management"]
    },
    {
      username: "matthewdavis",
      email: "matthew.davis@example.com",
      college: "Foster Group",
      degree: "B.Sc in Biotechnology",
      talents: ["Data Analysis", "Machine Learning"]
    },
    {
      username: "andreawilson",
      email: "andrea.wilson@example.com",
      college: "Butler LLC",
      degree: "B.Tech in Computer Science",
      talents: ["Web Development", "UI/UX Design"]
    }
  ];
  