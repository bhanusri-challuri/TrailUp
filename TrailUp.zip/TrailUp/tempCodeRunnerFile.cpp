#include <bits/stdc++.h>
using namespace std;

long long psum(const vector<int>& a) {
    int n = a.size();
    long long sum = 0;
    int currentMin = a[0];
    for (int i = 0; i < n; ++i) {
        currentMin = min(currentMin, a[i]);
        sum += currentMin;
    }
    return sum;
}

int main() {
    int t;
    cin >> t;

    while (t--) {
        int n;
        cin >> n;
        vector<int> a(n);
        for (int i = 0; i < n; ++i)
            cin >> a[i];

        long long r = psum(a); 

        int mini = a[0];
        for (int j = 1; j < n; ++j) {
            vector<int> temp = a;
            for (int i = 0; i < j; ++i) {
                vector<int> temp2 = a;
                temp2[i] += temp2[j];
                temp2[j] = 0;
                r = min(r, psum(temp2));
            }
        }

        cout << r << endl;
    }

    return 0;
}
